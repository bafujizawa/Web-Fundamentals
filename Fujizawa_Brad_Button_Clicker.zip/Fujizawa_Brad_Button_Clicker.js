function logout(elem)
{
    elem.innerText = "Logout";
}

function hide(elem)
{
    elem.parentElement.remove();
}

function myFunction()
{
    alert("Ninja was liked");
}